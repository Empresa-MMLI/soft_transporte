@extends ('layouts.app_cliente')
@section('html_title','SLA Dashboard | Visão Geral Cliente')
<!--Call of template welcome-->
@section('content')  <!--Section to show content to yield -->

<h1 class="h3 mb-3"><strong>Visão » </strong> Geral da conta</h1>
<div class="container-fluids">
<div class="row">
	<div class="col-sm-12">
			<span class="p-2 alert alert-success"> <i class="fa fa-info-circle"></i> Seja bem-vindo ao seu Perfil <strong>SLA - Agência de Turismo</strong> </span>
	</div>
</div>
</div>
@endsection
