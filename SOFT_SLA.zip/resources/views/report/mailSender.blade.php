<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Confirmação da compra do BIlhete</title>
</head>
<body>
<h1>{{ $info['titulo'] }}</h1><hr><hr><br>    
<p  style="font-size:1.1rem">{{ $info['sms'] }}</p><hr><br>
<p  style="font-size:0.9rem"> Número de Bilhete de viagem: <strong style="font-size:1.5rem">{{ $info['n_bilhete'] }} </strong> </p>
<p>MMLI - Soluções Comércio & Prestação de Serviços</p>    
</body>
</html>