<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Pontos_e_d extends Model
{
    use HasFactory;
    protected $table = 'pontos_e_d';
}
